currentattacks = {}
