# Raid-Toolbox

A big toolkit of spamming tools for discord.

### "it's for education purpose only"


Supports Windows, Linux, Mac, [Android](https://github.com/DeadBread76/Raid-Toolbox/wiki/How-to-set-up-Termux-to-run-RTB) and iOS with [iSH](https://ish.app/). (Tested on Windows 10 Education/Professional, Ubuntu 18.10, Mac OS Sierra (support droped) and Android 9 with Termux 0.72)

### BTC Address: 

**16uLpTNXMFc5HuTJYMsCQmr7dW4JbrZ33d**

### Need any help?

Check out the [Wiki](https://github.com/DeadBread76/Raid-Toolbox/wiki) and our [Telegram group](https://t.me/DeadBakery)

### Screenshots:

![Screenshot](https://raw.githubusercontent.com/DeadBread76/Raid-Toolbox/dev/RTBFiles/extras/screenshots/main.png)

![Joiner Menu](https://raw.githubusercontent.com/DeadBread76/Raid-Toolbox/dev/RTBFiles/extras/screenshots/joiner.png)

![Message Spammer](https://raw.githubusercontent.com/DeadBread76/Raid-Toolbox/dev/RTBFiles/extras/screenshots/messagespammer.png)

![VC Spammer](https://raw.githubusercontent.com/DeadBread76/Raid-Toolbox/dev/RTBFiles/extras/screenshots/vcspammer.png)

![Status Changer](https://raw.githubusercontent.com/DeadBread76/Raid-Toolbox/dev/RTBFiles/extras/screenshots/statuschanger.png)

![HypeSquad Changer](https://raw.githubusercontent.com/DeadBread76/Raid-Toolbox/dev/RTBFiles/extras/screenshots/hypesquadchanger.png)

Demonstration video: https://www.youtube.com/watch?v=suMXDkIXWfI (Outdated)

# `Features:`

**Custom Themes/Skins**

**Joiner and Leaver**

**Token Checker**

**Message Spammer**

**Ascii Spammer**

**Mass Mentioner**

**Voice Chat Spammer**

**DM Spammer**

**Group DM Spammer**

**Image Spammer**

**Embed Spammer**

**Role Mass Mentioner**

**Server Smasher**

**Plugins**

# `Installation:`

The instructions to install RTB can be found [here](https://github.com/DeadBread76/Raid-Toolbox/wiki/How-to-install-Python)


### `Python:`

Python 3.6 and 3.7 are compatible, you can get them here:

[Python 3.6.8](https://www.python.org/downloads/release/python-368/)

[Python 3.7.2](https://www.python.org/downloads/release/python-373/)


### `Configuration:`

Menu Theme can be changed by going to RTB > Themes > Change Theme, and setting can be changed in About > Settings. Alternatively, you can edit `config.json`.

![Dm spammed](http://i.imgur.com/FoVOBQml.jpg)

# **Disclaimer**

I am not responsible for any bans you might/will receive using Raid ToolBox, Nor am I responsible for damages caused with Raid ToolBox, or other peoples actions with this program.
